#pragma once

void serialOut(char c);