#pragma once
#define SUCCESS 0
#define EIO 1
#define EINVAL 2	//invalid parameter